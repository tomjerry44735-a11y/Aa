import getResponse from "./getResponse";

export { getResponse };
